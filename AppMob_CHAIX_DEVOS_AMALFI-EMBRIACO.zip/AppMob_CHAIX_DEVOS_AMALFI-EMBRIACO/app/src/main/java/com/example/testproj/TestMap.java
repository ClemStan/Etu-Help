package com.example.testproj;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class TestMap extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap map;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_map);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        /*
        Bundle bundle =  getIntent().getExtras();
        if (bundle != null) {
            if (bundle.getString("some") != null){
                Toast.makeText(getApplicationContext(), "data:" + bundle.getString("some"), Toast.LENGTH_SHORT).show();
            }
        } */

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        LatLng debut = new LatLng(48.854515370994896, 2.344221001737946);
        //map.addMarker(new MarkerOptions().position(new LatLng(48.857440, 2.296993)).title("Champ de mars").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.ic_baseline_restaurant_24)));
        map.moveCamera(CameraUpdateFactory.zoomTo(10)); //changer le zoom a convenance
        map.moveCamera(CameraUpdateFactory.newLatLng(debut));


        //CHANGER LES ICON DES MARKERS 

        //Depistage
        map.addMarker(new MarkerOptions().position(new LatLng(48.831112401402265, 2.3118641982284895)).title("Centre médico-social Ridder").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.depistage)));
        //Aide ali
        map.addMarker(new MarkerOptions().position(new LatLng(48.82682619284867, 2.381898784916739)).title("L’épicerie sociale étudiante du Secours Populaire").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.aideali)));
        map.addMarker(new MarkerOptions().position(new LatLng(48.85966331433483, 2.3826386982236922)).title("Epicerie solidaire Croix Rouge").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.aideali)));

        //Soutien mental
        map.addMarker(new MarkerOptions().position(new LatLng(48.84205248052648, 2.3413650982230814)).title("Libre Association Freudienne").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.ic_baseline_psychology_24)));
        map.addMarker(new MarkerOptions().position(new LatLng(48.82777243524744, 2.376153040550544)).title("FSEF : Relais Etudiants Lycéens").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.ic_baseline_psychology_24)));


        //SHopping
        map.addMarker(new MarkerOptions().position(new LatLng(48.854671800035085, 2.363377261474362)).title("Friperie Free'p'star").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.shopping)));
        map.addMarker(new MarkerOptions().position(new LatLng(48.852785755460985, 2.3333540183261037)).title("CityPharma").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.shopping)));
        map.addMarker(new MarkerOptions().position(new LatLng(48.88568403521357, 2.326635624782854)).title("Guerrisol").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.shopping)));
        map.addMarker(new MarkerOptions().position(new LatLng(48.858059407652306, 2.3525655514608403)).title("Free'p'star").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.shopping)));


        //parcs & nice spots
        map.addMarker(new MarkerOptions().position(new LatLng(48.846223370300955, 2.3367341437686426)).title("Jardin du Luxembourg").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.nice)));
        map.addMarker(new MarkerOptions().position(new LatLng(48.87998479962748, 2.309929214528577)).title("Parc Monceau").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.nice)));


        //resto + cafe
        map.addMarker(new MarkerOptions().position(new LatLng(48.8264727289764, 2.3589674098623075)).title("Boba Tea Factory").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.cafe)));


        //soins et bien etre
        map.addMarker(new MarkerOptions().position(new LatLng(48.85946644614031, 2.3559369982236933)).title("Académie Franck de Roche").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.selfcare)));



        map.addMarker(new MarkerOptions().position(new LatLng(48.82682619284867, 2.381898784916739)).title("L’épicerie sociale étudiante du Secours Populaire").icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.aideali)));









    }

    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId){
        Drawable vectorDrawable=  ContextCompat.getDrawable(context, vectorResId);
        vectorDrawable.setBounds(0,0,vectorDrawable.getIntrinsicWidth(),
                vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(),
                vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
}