package com.example.testproj;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AddActivity extends AppCompatActivity {

    MyDatabaseHelper db;

    Button add_data;
    EditText add_sujet;
    EditText add_desc;
    EditText add_auteur;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        db = new MyDatabaseHelper(this);

        add_data = findViewById(R.id.btnvalider); //a changer
        add_sujet = findViewById(R.id.addSujet); //a changer
        add_desc = findViewById(R.id.addDesc); //a changer
        add_auteur = findViewById(R.id.addAuteur); //a changer


        add_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sujet = add_sujet.getText().toString();
                String desc = add_desc.getText().toString();
                String auteur = add_auteur.getText().toString();

                if (!sujet.equals("") && db.insertData(sujet, desc, auteur)){
                    Toast.makeText(AddActivity.this, "Data added", Toast.LENGTH_SHORT).show();
                    add_sujet.setText("");
                }
                else {
                    Toast.makeText(AddActivity.this, "Data not added", Toast.LENGTH_SHORT).show();
                }
            }
        });




    }


    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;

                    switch (item.getItemId()) {
                        case R.id.nav_home:
                            selectedFragment = new HomeFragment();
                            break;
                        case R.id.nav_food:
                            selectedFragment = new FoodFragment();
                            break;
                        case R.id.nav_health:
                            selectedFragment = new HealthFragment();
                            break;
                        case R.id.nav_idees:
                            selectedFragment = new IdeesFragment();
                            //Intent in = new Intent(getActivity(), IdeesEtu.class);
                            //in.putExtra("some", "some data");
                            // startActivity(in);
                            break;
                    }

                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            selectedFragment).commit();

                    return true;
                }
            };
}