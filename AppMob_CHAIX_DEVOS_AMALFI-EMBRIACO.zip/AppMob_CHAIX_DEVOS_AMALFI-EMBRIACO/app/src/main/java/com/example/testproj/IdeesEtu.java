package com.example.testproj;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class IdeesEtu extends AppCompatActivity {


    MyDatabaseHelper db;

    ListView tips;
    ArrayList<String> listItem;
    ArrayAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_idees_etu);

        db = new MyDatabaseHelper(this);

        listItem = new ArrayList<>();
        tips = findViewById(R.id.listTips);


        viewData();

        tips.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
                String text = tips.getItemAtPosition(i).toString();
                Toast.makeText(IdeesEtu.this, ""+text, Toast.LENGTH_SHORT).show();
            }
        });

        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }



    private void viewData(){
        Cursor cursor = db.viewData();

        if( cursor.getCount() == 0){
            Toast.makeText(this, "No data to show", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()){
                listItem.add(cursor.getString(1) + " (par " + cursor.getString(3) + " )\n\n " + cursor.getString(2) + "\n"); //idex 1 pr le sujet et 0 pr l'id
            }
            adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listItem);
            tips.setAdapter(adapter);
        }
    }


    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selectedFragment = null;

                    switch (item.getItemId()) {
                        case R.id.nav_home:
                            selectedFragment = new HomeFragment();
                            break;
                        case R.id.nav_food:
                            selectedFragment = new FoodFragment();
                            break;
                        case R.id.nav_health:
                            selectedFragment = new HealthFragment();
                            break;
                        case R.id.nav_idees:
                            selectedFragment = new IdeesFragment();
                            //Intent in = new Intent(getActivity(), IdeesEtu.class);
                            //in.putExtra("some", "some data");
                            // startActivity(in);
                            break;
                    }

                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            selectedFragment).commit();

                    return true;
                }
            };

}